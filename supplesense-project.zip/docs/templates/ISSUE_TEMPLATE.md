# [Tipo] (Bug / Mejora / Contenido / Regla)
# [Prioridad] P1 / P2 / P3
# [Título]

## Contexto
- Ruta/pantalla:
- Entradas/escenario:
- Capturas (opcional):

## Pasos para reproducir
1.
2.
3.

## Expected
(¿Qué esperabas que pasara?)

## Actual
(¿Qué pasó realmente?)

## Criterios de aceptación
- [ ] 
- [ ] 
- [ ] 

## Notas y links
- 
