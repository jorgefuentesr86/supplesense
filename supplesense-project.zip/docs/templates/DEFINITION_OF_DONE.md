# Definition of Done (DoD)

- [ ] Cumple criterios de aceptación
- [ ] No rompe rutas existentes (smoke test completo)
- [ ] Probado en móvil y desktop
- [ ] Copys revisados (claridad + tono)
- [ ] Edge cases cubiertos (embarazo, renal, anticoagulantes)
- [ ] Notas de despliegue (si cambia schema o seeds)
