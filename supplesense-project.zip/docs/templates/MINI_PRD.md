# Mini-PRD

## Problema / oportunidad
(1–2 párrafos)

## Usuarios afectados
(Perfiles o segmentos)

## Objetivo
(1 frase, medible si aplica)

## Alcance
**Incluye:**  
-  
**No incluye:**  
-  

## Criterios de aceptación
- [ ] 
- [ ] 
- [ ] 

## Riesgos / supuestos
- 

## Métrica de éxito
- 
